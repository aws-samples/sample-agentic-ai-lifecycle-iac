import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """Simple policy lookup Lambda - returns policy document based on policy ID"""
    
    # Log the incoming event for debugging
    logger.info(f"Received event: {json.dumps(event)}")
    logger.info(f"Context: {context}")
    
    # Mock policy database
    policies = {
        "POL-001": {
            "policy_id": "POL-001",
            "policy_name": "Data Retention Policy",
            "version": "2.1",
            "effective_date": "2024-01-01",
            "owner": "Security Team",
            "description": "Defines data retention requirements for customer data",
            "requirements": [
                "Customer data must be retained for minimum 7 years",
                "Backup data must be encrypted at rest",
                "Data deletion requests must be processed within 30 days"
            ],
            "compliance_frameworks": ["SOC2", "GDPR", "HIPAA"]
        },
        "POL-002": {
            "policy_id": "POL-002",
            "policy_name": "Access Control Policy",
            "version": "1.5",
            "effective_date": "2024-03-15",
            "owner": "IT Security",
            "description": "Defines access control requirements for systems",
            "requirements": [
                "Multi-factor authentication required for all users",
                "Access reviews must be conducted quarterly",
                "Privileged access requires approval"
            ],
            "compliance_frameworks": ["SOC2", "ISO27001"]
        },
        "POL-003": {
            "policy_id": "POL-003",
            "policy_name": "Incident Response Policy",
            "version": "3.0",
            "effective_date": "2024-06-01",
            "owner": "Security Operations",
            "description": "Defines incident response procedures",
            "requirements": [
                "Security incidents must be reported within 1 hour",
                "Critical incidents require executive notification",
                "Post-incident reviews required within 48 hours"
            ],
            "compliance_frameworks": ["SOC2", "PCI-DSS"]
        }
    }
    
    # When called via Gateway MCP, parameters come directly in event
    # Gateway uses camelCase for parameter names
    policy_id = event.get('policyId') or event.get('policy_id') or event.get('policy-id')
    
    # Log what we received
    logger.info(f"Extracted policy_id: {policy_id}")
    logger.info(f"Event keys: {list(event.keys())}")
    
    if policy_id:
        policy_id = policy_id.upper()
    
    if not policy_id:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'policyId is required',
                'example': 'POL-001',
                'received_keys': list(event.keys())
            })
        }
    
    # Lookup policy
    policy = policies.get(policy_id)
    
    if policy:
        return {
            'statusCode': 200,
            'body': json.dumps(policy)
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({
                'error': f'Policy {policy_id} not found',
                'available_policies': list(policies.keys())
            })
        }
